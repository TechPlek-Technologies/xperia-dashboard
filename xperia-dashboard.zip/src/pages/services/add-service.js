// material-ui
import { Grid } from '@mui/material';
import { useEffect, useState } from 'react';
import AddServices from 'sections/add-service';
import { getData } from 'utils/clientFunctions';

// project-imports

// ==============================|| FORMS WIZARD ||============================== //

const AddService = () => {
  const pathname = window.location.pathname; // Endpoint (e.g., /about/123)

  console.log('Endpoint:', pathname);
  const [serviceData, setServiceData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const newData = await getData(`${process.env.REACT_APP_API_URL}/services${pathname}`);
        console.log(newData);
        setServiceData(newData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);
  return (
    <Grid container spacing={2.5} justifyContent="center">
      <Grid item xs={12} md={6} lg={7}>
        {serviceData && (
          <AddServices slug={pathname} serviceData={serviceData} setServiceData={setServiceData} serviceTitle={'Out of Home Services'} />
        )}
      </Grid>
    </Grid>
  );
};

export default AddService;
