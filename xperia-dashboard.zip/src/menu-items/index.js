// project-imports
import support from './support';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
  items: [support]
};

export default menuItems;
